<template>
  <div>这里是首页</div>
</template>

<script>
export default {
  name: "AppIndex"
}
</script>

<style scoped>

</style>