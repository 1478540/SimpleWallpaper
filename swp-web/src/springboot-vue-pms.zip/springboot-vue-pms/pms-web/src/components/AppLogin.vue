<template>
    <div class="box">
        <h2>用户登录</h2>
        <div class="input-box">
            <label>账号</label>
            <input type="text" v-model="name">
        </div>
        <div class="input-box">
            <label>密码</label>
            <input type="password" v-model="password">
        </div>
        <div class="btn-box">
            <a href="#">忘记密码?</a>
            <div>
                <button @click="login">登录</button>
                <button @click="y_register">注册</button>
            </div>
        </div>
    </div>
</template>
  
<script>
   
  
   export default {
  name: 'AppLogin',
  data() {
      return {
        name:'',
        password:'',
      }
    },
    methods:{
          y_register(){
            this.$router.push("/register");
          },
          y_login(){
              if(this.name=="a" && this.password=="2")
              {
                  alert("登录成功！");
                  this.$router.push("/index");
              }else
              {
                  alert("用户名或密码错误！");
              }
          },
          login() {
            let user = {
              no: this.name,
              password: this.password
            };
            let self = this;
            this.$axios.post('http://localhost:8090/user/login', user)
                .then(function (response) {
                  let result = response.data;
                  if (result.code === 200) {
                    console.log("登录成功！");
                    console.log("返回的数据：", result.data);
                    console.log("总记录数：", result.total);
                    self.$router.push("/index");
                  } else if (result.code === 400) {
                    console.log("登录失败！");
                  }
                })
                .catch(function (error) {
                  console.log("请求错误：", error);
                });

          }
      }
  }
  
  </script>
  
  <style scoped>
     @import '../assets/login.css';
  </style>
  
  